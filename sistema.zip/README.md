# COCOMO-II-Simulator
COCOMO_II is the Constructive cost estimation model for softwares used to calculate the estimated cost,time of developement and effort used in the software produced.
First of all open the Home.html file for the further links for SLOC and FP calculation.
SLOC.css contains all the css source code of all files in one single file.
JavaScript contents of all the html files is not written seprately. 
